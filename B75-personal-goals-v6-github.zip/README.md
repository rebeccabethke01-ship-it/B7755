# B75 Personal Goals

Personal habit tracker. Upload index.html to GitHub Pages. Data is stored locally; use Settings to export backups.
